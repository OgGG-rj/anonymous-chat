const socket = io();
const form = document.getElementById('form');
const input = document.getElementById('input');
const messages = document.getElementById('messages');

const randomName = 'User' + Math.floor(Math.random() * 10000);

form.addEventListener('submit', function(e) {
  e.preventDefault();
  if (input.value) {
    socket.emit('chat message', { user: randomName, message: input.value });
    input.value = '';
  }
});

socket.on('chat message', function(data) {
  const item = document.createElement('li');
  item.textContent = '🧑 ' + data.user + ': ' + data.message;
  messages.appendChild(item);
  messages.scrollTop = messages.scrollHeight;
});